#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WORDS 2045
int uniqueWords = 0;

typedef struct node
{
    int freq;
    char *word;
    struct node *left;
    struct node *right;

} Node;

int newWord(Node *words, char *word, int size)
{

    // printf("%s %d\uniqueWords",word,size);
    for (int i = 0; i < size; i++)
    {
        if (strcmp(words[i].word, word) == 0)
        {
            return i;
        }
    }
    return -1;
}
Node *initNode(char *word)
{
    Node *uniqueWords = calloc(1, sizeof(Node));
    strcpy(uniqueWords->word, word);
    uniqueWords->freq = 0;
    uniqueWords->left = NULL;
    uniqueWords->right = NULL;
    return uniqueWords;
}

int comp(const void *a, const void *b)
{
    Node *x = (Node *)a;
    Node *y = (Node *)b;

    return strcmp(x->word, y->word);
}

int getHeighestFreqIndex(Node *words, int l, int h)
{
    int high = 0;
    int index = -1;

    for (int i = l; i < h; i++)
    {
        if (words[i].freq > high)
        {
            high = words[i].freq;
            index = i;
        }
    }
    return index;
}

Node *buildTree(Node *words, int l, int h)
{

    int index = getHeighestFreqIndex(words, l, h);

    if (index == -1)
        return NULL;

    Node *root = &(words[index]);
    root->left = buildTree(words, l, index);
    root->right = buildTree(words, index + 1, h);

    return root;
}

void searchTree(Node *root, char *search)
{
    if (root == NULL)
    {
        printf("Not found\n");
    }
    else
    {   
        double freq = root->freq/2045.0;
        printf("Compared with %s (%.3lf), ", root->word, freq);
        int comp = strcmp(search, root->word);
        if (comp < 0)
        {
            printf("go left subtree\n");
            searchTree(root->left,search);
        }
        else if (comp > 0)
        {
            printf("go right subtree\n");
            searchTree(root->right,search);
        }
        else
        {
            printf("found\n");
        }
    }
}
int main()
{

    Node *words = calloc(WORDS, sizeof(Node));
    char temp[256];
    FILE *f = fopen("data_A4_Q1.txt", "r");
    while (fscanf(f, " %256s", temp) == 1)
    {
        // printf("%s\uniqueWords", temp);
        // fgetc(stdin);
        int res = newWord(words, temp, uniqueWords);
        if (res == -1)
        {
            // printf("new word %s\uniqueWords",temp);
            words[uniqueWords].word = calloc(256, sizeof(char));
            strcpy(words[uniqueWords].word, temp);
            words[uniqueWords].freq = 1;
            words[uniqueWords].left = NULL;
            words[uniqueWords].right = NULL;
            uniqueWords++;
        }
        else
        {
            words[res].freq++;
            // printf("updating word %s @ %d to %d\uniqueWords",temp,res,words[res].freq);
        }
    }
    fclose(f);

    qsort(words, uniqueWords, sizeof(Node), comp);

    Node *root = buildTree(words, 0, uniqueWords);

    char search[256];
    printf("Enter word to search\n");
    scanf("%s",search);
    searchTree(root,search);
    free(words);
    return 0;
}
