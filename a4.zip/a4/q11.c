#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WORDS 2045
int uniqueWords = 0;

typedef struct node
{
    int freq;
    char *word;
    struct node *left;
    struct node *right;

} Node;

Node *initNode(char *word)
{
    Node *uniqueWords = calloc(1, sizeof(Node));
    strcpy(uniqueWords->word, word);
    uniqueWords->freq = 0;
    uniqueWords->left = NULL;
    uniqueWords->right = NULL;
    return uniqueWords;
}

int comp(const void *a, const void *b)
{
    Node *x = (Node *)a;
    Node *y = (Node *)b;

    return strcmp(x->word, y->word);
}
int newWord(Node *words, char *word, int size)
{

    // printf("%s %d\uniqueWords",word,size);
    for (int i = 0; i < size; i++)
    {
        if (strcmp(words[i].word, word) == 0)
        {
            return i;
        }
    }
    return -1;
}
double getFreqSum(Node *words, int i, int j)
{
    double sum = 0;
    for (int k = i; k <= j; k++)
    {
        sum += words[k].freq;
    }
    return sum;
}

void buildTree(Node *words, double mainTable[uniqueWords][uniqueWords], int rootTable[uniqueWords][uniqueWords], int l, int h, char * search)
{
    int rootindex = rootTable[l][h];
    if(rootindex < l){
        printf("not found\n");
        return;
    }
    double freq = mainTable[l][h]/WORDS;
    int comp =  strcmp(search,words[rootindex].word);
    // printf("r=%d l=%d h=%d\n",rootindex, l, h);

    printf("Compared with %s (%.3lf), ", words[rootindex].word, freq);
    if(comp < 0){
        printf("go left subtree\n");
        buildTree(words,mainTable,rootTable,l,rootindex-1,search);
    }else if (comp > 0){
        printf("go right subtree\n");
        buildTree(words,mainTable,rootTable,rootindex+1,h,search);
    }else{
        printf("found\n");
    }
}

int main()
{

    Node *words = calloc(WORDS, sizeof(Node));
    char temp[256];
    FILE *f = fopen("data_A4_Q1.txt", "r");
    while (fscanf(f, " %256s", temp) == 1)
    {
        // printf("%s\uniqueWords", temp);
        // fgetc(stdin);
        int res = newWord(words, temp, uniqueWords);
        if (res == -1)
        {
            // printf("new word %s\uniqueWords",temp);
            words[uniqueWords].word = calloc(256, sizeof(char));
            strcpy(words[uniqueWords].word, temp);
            words[uniqueWords].freq = 1;
            words[uniqueWords].left = NULL;
            words[uniqueWords].right = NULL;
            uniqueWords++;
        }
        else
        {
            words[res].freq++;
            // printf("updating word %s @ %d to %d\uniqueWords",temp,res,words[res].freq);
        }
    }
    fclose(f);

    qsort(words, uniqueWords, sizeof(Node), comp);
    // for (int i = 0; i < uniqueWords; i++)
    // {
    //     printf("%s %d\n", words[i].word, words[i].freq);
    // }
    // printf("%d\n", uniqueWords);
    double mainTable[uniqueWords][uniqueWords];
    int rootTable[uniqueWords][uniqueWords];

    for (int i = 0; i < uniqueWords; i++)
    {
        mainTable[i][i] = words[i].freq;
    }

    for (int L = 2; L <= uniqueWords; L++)
    {
        for (int i = 0; i <= uniqueWords - L + 1; i++)
        {
            int j = i + L - 1;
            int totalFreq = getFreqSum(words, i, j);
            mainTable[i][j] = 99999999;

            for (int r = i; r <= j; r++)
            {
                double p1 = 0;
                double p2 = 0;
                if(r > i)
                    p1 = mainTable[i][r - 1];
                if(r < j)
                    p2 = mainTable[r + 1][j];

                double minProb = p1 + p2 + totalFreq;
                if (minProb < mainTable[i][j])
                {
                    mainTable[i][j] = minProb;
                    rootTable[i][j] = r;
                }
            }
        }
    }

    char search[256];
    printf("Enter term to search\n");
    scanf("%s",search);
    buildTree(words, mainTable, rootTable, 0, uniqueWords - 1,search);
    free(words);
    return 0;
}