#include <stdio.h>
#include <stdlib.h>

typedef struct mate
{
    int takenBy;
    int pref[4];
    int nextPref;
} Mate;

int nextFree(Mate *list, int n)
{
    for (int i = 0; i < n; i++)
    {
        if (list[i].takenBy == -1)
            return i;
    }
    return -1;
}

int isBetterMate(Mate *mate, int newMate, int n)
{
    // printf("%d vs %d\n",mate->takenBy,newMate);
    int newMateIndex = mate->pref[newMate];
    int oldMateIndex = mate->pref[mate->takenBy];
    return newMateIndex < oldMateIndex ? 1 : 0;
}

int main(int argc, char *argv[])
{

    if (argc < 2)
    {
        printf("usage ./q2 file.txt\n");
        return 0;
    }
    char temp[32];
    FILE *fp = fopen(argv[1], "r");
    fgets(temp, 32, fp);
    int n = atoi(temp);

    Mate *men = calloc(n * 2, sizeof(Mate));
    Mate *women = &(men[n]);
    // printf("%d\n", n);
    int i = 0;
    int j = 0;
    while (fscanf(fp, " %256s", temp) == 1)
    {
        if (j != 0 && j % n == 0)
        {
            i++;
            j = 0;
        }
        // printf("[%d][%d] %d\n", i, j, atoi(temp));
        men[i].takenBy = -1;
        men[i].nextPref = 0;
        men[i].pref[j] = atoi(temp);
        j++;
    }

    int freeManIndex;
    while ((freeManIndex = nextFree(men, n)) != -1)
    {
        Mate *man = &(men[freeManIndex]);
        // printf("freeman %d with pref[%d]=%d \n", freeManIndex, man->nextPref, man->pref[man->nextPref]);
        int manNextPref = man->pref[man->nextPref] - 1;
        Mate *woman = &(women[manNextPref]);
        // printf("%c proposes to %c\n", freeManIndex + 97, manNextPref + 65);
        if (woman->takenBy == -1 || isBetterMate(woman, freeManIndex, n) == 1)
        { // next best woman free or better mate
            if (woman->takenBy != -1)
            {
                // printf("%c replaces %c\n", manNextPref + 65, woman->takenBy + 97);
                men[woman->takenBy].takenBy = -1;
                men[woman->takenBy].nextPref++;
            }
            // printf("%c accepts %c\n", manNextPref + 65, freeManIndex + 97);
            woman->takenBy = freeManIndex;
            man->takenBy = man->pref[man->nextPref];
        }
        else
        {
            // printf("%c rejects %c\n", manNextPref + 65, freeManIndex + 97);
            man->nextPref++;
        }
        // fgetc(stdin);

    }

    for (int i = 0; i < n; i++)
    {
        // printf("%d-->%d\n",i,men[i].takenBy);
        for (int j = 0; j < n; j++)
        {
            int x = 0;
            if (j == women[i].takenBy)
                x = 1;
            printf(" %d", x);
        }
        printf("\n");
    }

    fclose(fp);
    free(men);

    return 0;
}
